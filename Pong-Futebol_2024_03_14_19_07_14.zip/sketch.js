// Declaração das variáveis 

let jogador, computador, bola;
let barraSuperior, barraInferior;
let pontuacaoJogador = 0, pontuacaoComputador = 0;
let botaoReiniciarX = 400, botaoReiniciarY = 150, botaoReiniciarW = 100, botaoReiniciarH = 50;


function preload() {
  Fundo = loadImage('Imagens/jogo.png');
  placar = loadImage('Imagens/placar.png');
  fonte = loadFont('fonte.ttf');
  trilha = loadSound('sons/torcida.mp3');
  chute = loadSound('sons/chute.mp3');
  gol = loadSound('sons/gol.mp3');
  vitoria = loadSound('sons/vitoria.mp3');
  derrota = loadSound('sons/derrota.mp3');
}

// Função setup
function setup() {
  
  botaoReiniciarX = 400;
  botaoReiniciarH = 90;
  botaoReiniciarY = 360;
  botaoReiniciarW = 150; 
  createCanvas(800, 400);
  trilha.loop(0,1,0.2);
  jogador = new Raquete(true);
  computador = new Raquete(false);
  bola = new Bola(computador.x - computador.w / 2 - 10, computador.y);
  barraSuperior = new Barra(true);
  barraInferior = new Barra(false);
  
}

// Função draw
function draw() {  
  
  
// Define o fundo do canvas e o placar
  image(Fundo, 0, 0, width, height);  
  image(placar, 150, -210, placar.width, placar.height);
  fill(255,255,255);
  textSize(35);
  textAlign(CENTER);
  textFont(fonte);
  text(pontuacaoJogador, 190, 52);
  text(pontuacaoComputador, 610, 52);
  text("PLAYER", 260, 50);
  text("BOOT", 550, 50); 
  
  
// Verifica quem ganhou
  if (pontuacaoJogador === 3 || pontuacaoComputador === 3) {
    trilha.stop(); 
    if (pontuacaoJogador > pontuacaoComputador) {
      vitoria.play(0,1,0.4);
      fill(0,128,0);
      textSize(70);
      text("VITÓRIA!",400, 220 ); 
    } else {
      derrota.play(0,1,0.2);
      fill(255, 0, 0);
      textSize(70);
      text("DERROTA!",400, 220);
    }  
noLoop();
 }  

    
  
// Verifica se a bola colide com as raquetes do jogador ou do computador, ou com as barras superior e inferior
  bola.verificaRaquete(jogador);
  bola.verificaRaquete(computador);
  bola.verificaBarra(barraSuperior);
  bola.verificaBarra(barraInferior);

// Exibe as raquetes do jogador e do computador, e as barras superior e inferior
  jogador.show();
  computador.show();
  barraSuperior.show();
  barraInferior.show();

// Atualiza a posição das raquetes do jogador e do computador
  jogador.update();
  computador.update();
  
  bola.update(); // Atualiza a posição da bola
  bola.bordas(); // Verifica se a bola atinge as bordas do canvas
  bola.mostrar();// Exibe a bola
}

// Função parar o movimento da raquete
function keyReleased() {
  if (keyCode === UP_ARROW || keyCode === DOWN_ARROW) {
    jogador.move(0);
  }
}

// Função mover a raquete do jogador
function keyPressed() {
  if (keyCode === UP_ARROW) {
    jogador.move(-5);
  } else if (keyCode === DOWN_ARROW) {
    jogador.move(5);
  }
}

// Construtor da Raquete
function Raquete(isLeft) {
  // Inicializa as propriedades da raquete
  this.y = height / 2;
  this.w = 10;
  this.h = 100;
  this.ychange = 0;

  // Posiciona a raquete à esquerda ou à direita dependendo do parâmetro isLeft
  if (isLeft) {
    this.x = 15;
  } else {
    this.x = width - this.w;
  }

  
// Método para atualizar a posição da raquete
this.update = function() {
  // Raquete do computador para a posição futura prevista da bola
  if (!isLeft) {
    let posicaoFutura = bola.y + bola.yspeed * 20; 
    // Preveja a posição da bola 30 quadros no futuro
    let direcao = posicaoFutura - this.y;
    this.y += direcao * 0.03;
    // Ajuste este valor para controlar a velocidade da raquete do computador
  } else {
    // Se a raquete é do jogador, atualiza a posição y da raquete com base na entrada do teclado
    this.y += this.ychange;
  }
  // Restringe a posição y da raquete para que não saia do canvas
  this.y = constrain(this.y, this.h / 2 + barraSuperior.h, height - this.h / 2 - barraInferior.h);
};


  // Método para mover a raquete com base na entrada do teclado
  this.move = function(steps) {
    this.ychange = steps;
  };

  // Método para exibir a raquete
  this.show = function() {
    fill(255);
    rectMode(CENTER);
    rect(this.x, this.y, this.w, this.h);
  };
  
}

// Construtor Barras
function Barra(isTop) {
  // Inicializa as propriedades da barra
  this.x = width / 2;
  this.w = width;
  this.h = 10;

  // Posiciona a barra no topo ou na base do canvas dependendo
  if (isTop) {
    this.y = this.h / 2;
  } else {
    this.y = height - this.h / 2;
  }

  // Método para exibir a barra
  this.show = function() {
    fill(255);
    rectMode(CENTER);
    rect(this.x, this.y, this.w, this.h);
  };
}

// Construtor Bola
function Bola(x, y) {
  this.x = x || width / 2;
  this.y = y || height / 2;
  this.xspeed = random(3,5);
  this.yspeed = random(3,5);
  
  
  // Método para exibir a bola
  this.mostrar = function() {
    fill(255);
    ellipse(this.x, this.y, 20);
  };

  // Método para atualizar a posição da bola
  this.update = function() {
    this.x += this.xspeed;
    this.y += this.yspeed;
  };

  // Método para verificar se a bola atinge as bordas do canvas
  this.bordas = function() {
  if (this.y - 10 < 0 || this.y + 10 > height) {
    this.yspeed *= -1;
  }
  if (this.x - 10 < 0) {
    this.x = jogador.x + jogador.w / 2 + 10;
    this.y = jogador.y;
    this.xspeed = random(3,5);
    this.yspeed = random(3,5);
    pontuacaoComputador++;
    gol.play(0,1,0.2);
            
  } else if (this.x + 10 > width) {
    this.x = computador.x - computador.w / 2 - 10;
    this.y = computador.y;
    this.xspeed = random(3,5);
    this.yspeed = random(3,5);
    pontuacaoJogador++;
    gol.play(0,1,0.2);
             

  }
};

  // Método para verificar se a bola colide com uma raquete
  this.verificaRaquete = function(raquete) {
  if (this.y - 10 < raquete.y + raquete.h / 2 && this.y + 10 > raquete.y - raquete.h / 2) {  
    if (this.x - 10 < raquete.x + raquete.w / 2 && this.x + 10 > raquete.x - raquete.w / 2) {
      if ((this.x < raquete.x && this.xspeed > 0) || (this.x > raquete.x && this.xspeed < 0)) {  

        this.xspeed *= -1.1; // Aumenta a velocidade no eixo x em 10%
        this.yspeed *= 1.1;  // Aumenta a velocidade no eixo y em 10%
        chute.play(0,1,0.2);
      }
    }
  }
}
 
  // Método para verificar se a bola colide com uma barra
  this.verificaBarra = function(barra) {
    if (this.x - 10 < barra.x + barra.w / 2 && this.x + 10 > barra.x - barra.w / 2) {
      if (this.y - 10 < barra.y + barra.h / 2 && this.y + 10 > barra.y - barra.h / 2) {
        this.yspeed *= -1;
      }
    }  
  };
}




